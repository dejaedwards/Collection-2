var CollectionList: [String] = ["Rings","Rocks","Incense","Phone Cases","Videogame Skins","Shoes","Jewelry","Bikes","Lip Gloss","Lotion"]
print("Our collection list has \(CollectionList.count) items.")
for item in CollectionList {
    print(item)
}

let sortedArray = CollectionList.sorted(by: {$0 < $1})
print(sortedArray)


